# ChangeLog for tls-session-manager

## 0.0.7

* Naming threads.

## 0.0.6

* Preparing for tls v2.1.

## 0.0.5

* Supporting "tls" v2.0.0.

## 0.0.4

* Supporting "tls" v1.5.3.

## 0.0.3

* Adding Strict and StrictData pragma

## 0.0.2.1

* Supporting "tls" v1.5.0.

## 0.0.2.0

* Using ShortByteString internally to avoid ByteString's fragmentation.
* The default value of dbMaxSize is now 1,000.

## 0.0.1.0

* Supporting sessionResumeOnlyOnce.

## 0.0.0.0
* A first release.

module Network.TLS.Util.Serialization (
    os2ip,
    i2osp,
    i2ospOf_,
) where

import Crypto.Number.Serialize (i2osp, i2ospOf_, os2ip)
